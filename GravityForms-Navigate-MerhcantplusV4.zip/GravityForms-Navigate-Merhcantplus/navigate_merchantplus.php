<?php
/*
Plugin Name: Gravity Forms Navigate Merchantplus Add-On
Plugin URI: http://merchantplus.com
Description: Accept credit card payments through Gravity Forms, simply with Navigate Merchantplus
Version: 0.1.1
Author: Navigate
Author URI: https://www.merchantplus.com

------------------------------------------------------------------------
*/

$gf_merchantplus_file = __FILE__;

define('GRAVITYFORMS_MERCHANTPLUS_FILE', $gf_merchantplus_file);
define('GRAVITYFORMS_MERCHANTPLUS_PATH', WP_PLUGIN_DIR . '/' . basename(dirname($gf_merchantplus_file)));

add_action('init', array('GFMerchantplus', 'init'));

register_activation_hook(GRAVITYFORMS_MERCHANTPLUS_FILE, array('GFMerchantplus', 'add_permissions'));

class GFMerchantplus
{
    private static $path                     = 'navigate-merchantplus/navigate_merchantplus.php';
    private static $url                      = 'http://www.gravityforms.com';
    private static $slug                     = 'navigate-merchantplus';
    private static $version                  = '0.1';
    private static $min_gravityforms_version = '1.9';
    private static $transaction_response     = '';
    private static $log                      = null;
    const GATEWAY_URL                        = 'https://gateway.merchantplus.com/cgi-bin/PAWebClient.cgi';

    //Plugin starting point. Will load appropriate files
    public static function init()
    {
        if (!self::is_gravityforms_supported())
            return;

        if (is_admin()) {
            //enables credit card field
            add_filter('gform_enable_credit_card_field', '__return_true');

            if (RGForms::get('page') == 'gf_settings') {
                RGForms::add_settings_page('Navigate Merchantplus (Payments)', array('GFMerchantplus', 'settings_page'), self::get_base_url() . '/images/merchantplus_wordpress_icon_32.png');
                add_filter('gform_currency_disabled', '__return_true');

                //loading Gravity Forms tooltips
                require_once(GFCommon::get_base_path() . '/tooltips.php');
                add_filter('gform_tooltips', array('GFMerchantplus', 'tooltips'));
            }

            add_action( "gform_field_standard_settings", array( "GFMerchantplus", "field_settings_checkbox" ), 10, 2 );
            add_action( "gform_editor_js", array( "GFMerchantplus", "field_settings_js" ) );

        } else {
            //handling post submission.
            add_filter('gform_field_validation', array('GFMerchantplus', 'gform_field_validation'), 10, 4);
            add_filter('gform_validation', array('GFMerchantplus', 'merchantplus_validation'), 10, 4);
            add_action('gform_after_submission', array('GFMerchantplus', 'merchantplus_after_submission'), 10, 2);
        }
    }

    /**
     * @static Add Merchantplus tooltips to the base tooltips
     * @param $tooltips
     * @return array
     */
    public static function tooltips($tooltips)
    {
        $merchantplus_tooltips = array(
            'merchantplus_username'  => '<h6>' . __('Username', 'navigate-merchantplus') . '</h6>' . __('Enter the Username for your Merchantplus account.', 'navigate-merchantplus'),
            'merchantplus_token'     => '<h6>' . __('Token', 'navigate-merchantplus') . '</h6>' . __('Enter the Token for your Merchantplus account.', 'navigate-merchantplus'),
            'merchantplus_test_mode' => '<h6>' . __('Test Mode', 'navigate-merchantplus') . '</h6>' . __('Turn on Test Mode for your Merchantplus account. This will use your test merchant account.', 'navigate-merchantplus'),
            'merchantplus_auth_mode' => '<h6>' . __('Sandbox Mode', 'navigate-merchantplus') . '</h6>' . __('Turn on Test Mode for your Merchantplus account. This will not interact with your bank.', 'navigate-merchantplus')
            );
        return array_merge($tooltips, $merchantplus_tooltips);
    }

    /**
     * @static Render the settings page for Gravity Forms
     */
    public static function settings_page()
    {
        if (isset($_POST["uninstall"])) {
            check_admin_referer('uninstall', 'gf_merchantplus_uninstall');
            self::uninstall();
            ?>
            <div class="updated fade" style="padding:20px;">
                <?php _e(sprintf("Gravity Forms Merchantplus Add-On has been successfully uninstalled. It can be re-activated from the %splugins page%s.", "<a href='plugins.php'>", "</a>"), 'navigate-merchantplus')?>
            </div>
            <?php
            return;
        } else if (isset($_POST["gf_merchantplus_submit"])) {
            check_admin_referer('update', 'gf_merchantplus_update');
            $settings = array(
                'username'  => $_POST['merchantplus_username'],
                'token'     => $_POST['merchantplus_token'],
                'test_mode' => (bool)$_POST['merchantplus_test_mode'],
                'auth_mode' => $_POST['merchantplus_auth_mode']
                );
            update_option('gf_merchantplus_settings', $settings);
            $fz_updated = true;
        } else {
            $settings = get_option('gf_merchantplus_settings');
        }

        ?>
        <form method="post" action="">
            <?php wp_nonce_field('update', 'gf_merchantplus_update') ?>

            <h3><?php _e('Merchantplus Settings', 'navigate-merchantplus') ?></h3>

            <?php if ($fz_updated) { ?>
            <div class="updated fade" style="padding: 20px;">Your settings have been updated.</div>
            <?php } ?>

            <p style="text-align: left;">
                <?php _e("MerchantPlus offers a range of leading gateways and processing options -- all with a big, giant easy button. With 100's of certified shopping carts, billing systems, subscription management platforms and business apps to choose from, getting started with MerchantPlus is as easy as it gets.", "navigate-merchantplus"); ?>
            </p>

            <table class="form-table">
                <tr>
                    <th scope="row" nowrap="nowrap">
                        <label for="merchantplus_username"><?php _e('Username', 'navigate-merchantplus'); ?> <?php gform_tooltip('merchantplus_username') ?></label>
                    </th>
                    <td width="88%">
                        <input class="size-1" id="merchantplus_username" name="merchantplus_username" value="<?php echo esc_attr($settings["username"]); ?>"/>
                    </td>
                </tr>
                <tr>
                    <th scope="row" nowrap="nowrap">
                        <label for="merchantplus_token"><?php _e('Transaction Key', 'navigate-merchantplus'); ?> <?php gform_tooltip('merchantplus_token') ?></label>
                    </th>
                    <td width="88%">
                        <input class="size-1" id="merchantplus_token" name="merchantplus_token" value="<?php echo esc_attr($settings["token"]); ?>"/>
                        <br/>
                        <small><?php _e("Your <strong>Username</strong> and <strong>Transaction Key</strong> can be found on your account settings page in your <a href='https://gateway.navigate.com' target='_blank'>Dashboard</a>", "navigate-merchantplus") ?></small>
                    </td>
                </tr>
                <tr>
                    <th scope="row" nowrap="nowrap">
                        <label for="merchantplus_test_mode"><?php _e('Use Test Mode', 'navigate-merchantplus'); ?> <?php gform_tooltip('merchantplus_test_mode') ?></label>
                    </th>
                    <td width="88%">
                        <select name="merchantplus_test_mode" id="merchantplus_test_mode">
                            <option value="1"<?php echo $settings["test_mode"] ? " selected='selected'" : ""; ?>>Yes</option>
                            <option value="0"<?php echo $settings["test_mode"] ? "" : " selected='selected'"; ?>>No</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row" nowrap="nowrap">
                        <label for="merchantplus_auth_mode"><?php _e('Authorization Mode', 'navigate-merchantplus'); ?> <?php gform_tooltip('merchantplus_auth_mode') ?></label>
                    </th>
                    <td width="88%">
                        <select name="merchantplus_auth_mode" id="merchantplus_auth_mode">
                            <option value="AUTH_ONLY"<?php echo $settings["auth_mode"] == "AUTH_ONLY" ? " selected='selected'" : ""; ?>>Authorization</option>
                            <option value="AUTH_CAPTURE"<?php echo $settings["auth_mode"] == "AUTH_ONLY" ? "" : " selected='selected'"; ?>>Capture</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="gf_merchantplus_submit" class="button-primary" value="<?php _e('Save Settings', 'navigate-merchantplus') ?>"/></td>
                </tr>
            </table>
        </form>

        <form action="" method="post">
            <?php wp_nonce_field('uninstall', 'gf_merchantplus_uninstall') ?>
            <?php if (GFCommon::current_user_can_any('gravityforms_merchantplus_uninstall')) { ?>
                <div class="hr-divider"></div>

                <h3><?php _e('Uninstall Merchantplus Add-On', 'navigate-merchantplus') ?></h3>
                <div class="delete-alert">
                    <?php
                    $uninstall_button = '<input type="submit" name="uninstall" value="' . __('Uninstall Merchantplus Add-On', 'navigate-merchantplus') . '" class="button" onclick="return confirm(\'' . __("Warning! This will disable all forms which use Merchantplus. This cannot be undone. \'OK\' to delete, \'Cancel\' to stop", 'navigate-merchantplus') . '\');"/>';
                    echo apply_filters('gform_merchantplus_uninstall_button', $uninstall_button);
                    ?>
                </div>
                <?php } ?>
            </form>
            <?php
        }

    /**
     * @static
     * Add permissions for the plugin
     */
    public static function add_permissions()
    {
        global $wp_roles;
        $wp_roles->add_cap('administrator', 'gravityforms_merchantplus');
        $wp_roles->add_cap('administrator', 'gravityforms_merchantplus_uninstall');
    }

    /**
     * @static Capabilities for members
     * @param $caps
     * @return array
     */
    public static function members_get_capabilities($caps)
    {
        return array_merge($caps, array('gravityforms_merchantplus', 'gravityforms_merchantplus_uninstall'));
    }

    /**
     * @static Fetch the credit card field from the form
     * @param $form
     * @return bool
     */
    public static function get_creditcard_field($form)
    {
        $fields = GFCommon::get_fields_by_type($form, array('creditcard'));
        return empty($fields) ? false : $fields[0];
    }


    /**
     * @static Determine if the current page is the 'last' page
     * @param $form
     * @return bool
     */
    private static function is_last_page($form)
    {
        $current_page = GFFormDisplay::get_source_page($form["id"]);
        $target_page  = GFFormDisplay::get_target_page($form, $current_page, rgpost('gform_field_values'));
        return $target_page == 0;
    }


    /**
     * @static Perform validation on the card fields
     * @param $validation_result
     * @param $value
     * @param $form
     * @param $field
     * @return array
     */
    public static function gform_field_validation($validation_result, $value, $form, $field)
    {
        if ($field['type'] == 'creditcard') {
            $card_number_valid     = rgpost('card_number_valid');
            $exp_date_valid        = rgpost('exp_date_valid');
            $cvc_valid             = rgpost('cvc_valid');
            $cardholder_name_valid = rgpost('cardholder_name_valid');
            $create_token_error    = rgpost('create_token_error');
            if (('false' == $card_number_valid) || ('false' == $exp_date_valid) || ('false' == $cvc_valid) || ('false' == $cardholder_name_valid)) {
                $validation_result['is_valid'] = false;
                $message = ('false' == $card_number_valid) ? __('Invalid credit card number.', 'navigate-merchantplus') : '';
                $message .= ('false' == $exp_date_valid) ? __(' Invalid expiration date.', 'navigate-merchantplus') : '';
                $message .= ('false' == $cvc_valid) ? __(' Invalid security code.', 'navigate-merchantplus') : '';
                $message .= ('false' == $cardholder_name_valid) ? __(' Invalid cardholder name.', 'navigate-merchantplus') : '';
                $validation_result['message']  = sprintf(__('%s', 'navigate-merchantplus'), $message);
            } else if (!empty($create_token_error)) {
                $validation_result['is_valid'] = false;
                $validation_result['message']  = sprintf(__('%s', 'navigate-merchantplus'), $create_token_error);
            } else {
                $validation_result['is_valid'] = true;
                unset($validation_result['message']);
            }
        }

        return $validation_result;
    }

    /**
     * @static Checks for a card field, and if present (and visible) process the payment
     * @param $validation_result
     * @return array
     */
    public static function merchantplus_validation($validation_result)
    {
        $form   = $validation_result["form"];
        $fields = GFCommon::get_fields_by_type( $form, array( 'creditcard' ) );

        if (empty($fields)) {
            return $validation_result;
        }
        else {
            if(RGFormsModel::is_field_hidden( $form, $fields[0], array())) {
                return $validation_result;
            } else {
                return self::make_product_payment($validation_result);
            }
        }
    }


    /**
     * @static Perform the transaction against Merchantplus
     * @param $params array - expects: card_token|(card_number, card_holder, cvv, card_expiry)
     * @return array|WP_Error
     */
    private static function do_payment($navigate_data) {

        $url  = self::GATEWAY_URL;
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_PORT, 443);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_FORBID_REUSE, 1);
        curl_setopt($curl, CURLOPT_FRESH_CONNECT, 1);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($navigate_data, '', '&'));

        $response = curl_exec($curl);
    //print_r($response); exit;
        $json = array();

        if (curl_error($curl)) {
          $error = new WP_Error();
          $error->add(1, 'CURL ERROR: ' . curl_errno($curl) . '::' . curl_error($curl));
          $error->add_data($response);
          return $error;
        } elseif ($response) {
            $i = 1;

            $response_info = array();

            $results = explode('|', $response);
            foreach ($results as $result) {
                $response_info[$i] = trim($result, '"');

                $i++;
            }

            if ($response_info[1] == '1') {
                $message = '';

                if (isset($response_info['5'])) {
                    $message .= 'Authorization Code: ' . $response_info['5'] . "\n";
                }

                if (isset($response_info['6'])) {
                    $message .= 'AVS Response: ' . $response_info['6'] . "\n";
                }

                if (isset($response_info['7'])) {
                    $message .= 'Transaction ID: ' . $response_info['7'] . "\n";
                }

                if (isset($response_info['39'])) {
                    $message .= 'Card Code Response: ' . $response_info['39'] . "\n";
                }

                if (isset($response_info['40'])) {
                    $message .= 'Cardholder Authentication Verification Response: ' . $response_info['40'] . "\n";
                }

                return array(
                    "transaction_id" => $response_info['7'],
                    "card_token"     => $response_info['39'] ,
                    "amount"         => $response_info['10']
                    );

            } else {
                $error = new WP_Error();
                $error->add(4,$response_info[4]);
                return $error;
            }
        } else {
            $error = new WP_Error();
            $error->add(4, "Navigate CURL ERROR: Empty Gateway Response");
            return $error;
        }

        curl_close($curl);
    }

    /**
     * @static Extract the card details form the field
     * @param $field the GF creditcard field
     * @return array
     */
    private static function extract_card_details($field) {
        $values = array();
        foreach($field["inputs"] as &$input) {
            switch($input["label"]) {
                case "Card Number":
                $values["card_number"] = rgpost("input_" . str_replace(".", "_", $input["id"]));
                break;

                case "Expiration Month":
                $raw = rgpost("input_" . str_replace(".", "_", $field["id"]."_2"));
                $values["card_expiry"] = $raw[0] . "" . substr($raw[1], -2);
                break;

                case "Security Code":
                $values["cvv"] = rgpost("input_" . str_replace(".", "_", $input["id"]));
                break;

                case "Cardholder's Name":
                $values["card_holder"] = rgpost("input_" . str_replace(".", "_", $input["id"]));
                break;
            }
        }

        return $values;
    }

    /**
     * @static Extract the product details from the field
     * @param $field the GF product field
     * @return array
     */
    // private static function extract_product_details($field) {
    //     $amount = 0;
    //     $quantity = 0;

    //     foreach($field["inputs"] as &$input) {
    //         switch($input["label"]) {
    //             case "Price":
    //                 $raw    = rgpost("input_" . str_replace(".", "_", $input["id"]));
    //                 $amount += (int)(floatval(str_replace("$", "", $raw)));
    //             break;

    //             case "Quantity":
    //                 $raw      = rgpost("input_" . str_replace(".", "_", $input["id"]));
    //                 $quantity = (int)$raw;
    //             break;
    //         }
    //     }

    //     return array("amount" => $amount * $quantity);
    // }

    public static function &get_credit_card_field ( &$form ) {
        foreach ( $form["fields"] as &$field ) {
            if ($field["type"] == "creditcard" ) {
                return $field;
            }
        }
        $null = null;
        return $null;
    }

    /**
     * @static Perform the product payment and handle the response. If the payment fails it is added as an failed validation.
     * @param $validation_result
     * @return array
     */
    private static function make_product_payment($validation_result)
    {
        // Extract form fields
        $form      = $validation_result["form"];
        $cc_field  = &GFMerchantplus::get_credit_card_field( $form );
        $ps_fields = GFMerchantplus::paymentspring_fields( );

        foreach( GFMerchantplus::paymentspring_fields( ) as $key => $value ) {
            $id = rgar( $cc_field, "field_paymentspring_{$key}" );
            if ( $id ) {
                $ps_fields[$key] = rgpost( "input_" . str_replace( ".", "_", $id ) );
            }
            else {
                $ps_fields[$key] = null;
            }
        }

        $details = array();
        foreach($form["fields"] as &$field) {
            switch($field["type"]) {
                case "creditcard":
                $details = array_merge($details, self::extract_card_details($field));
                break;
                // case "product":
                // $details = array_merge($details, self::extract_product_details($field));
                // break;
            }
        }

        $details["reference"]   = strtoupper(uniqid('GF-'));
        $details["customer_ip"] = $_SERVER['REMOTE_ADDR'];
        $settings               = get_option('gf_merchantplus_settings');



        $navigate_data = array();

    // Merchant Info
        $navigate_data['x_login']              = $settings["username"];
        $navigate_data['x_tran_key']           = $settings["token"];

    // AIM Head
        $navigate_data['x_version']            = '3.1';
        $navigate_data['x_delim_data']         = 'TRUE';
        $navigate_data['x_delim_char']         = '|';
        $navigate_data['x_relay_response']     = 'FALSE';

    // Transaction Info
        $navigate_data['x_method']             = 'CC';
        $navigate_data['x_type']               = $settings["auth_mode"];
        $navigate_data['x_amount']             = floatval((str_replace(array('$', '.', ','), "", $ps_fields["amount"]) / 100));

    // Test Card
        $navigate_data['x_card_num']           = $details["card_number"];
        $navigate_data['x_exp_date']           = $details["card_expiry"];
        $navigate_data['x_card_code']          = $details["cvv"];
        $navigate_data['x_trans_id']           = '';

    // Order Info
        $navigate_data['x_invoice_num']        = '';
        $navigate_data['x_description']        = '';

    // Customer Info
        $navigate_data['x_first_name']         = $ps_fields["first_name"];
        $navigate_data['x_last_name']          = $ps_fields["last_name"];
        $navigate_data['x_company']            = $ps_fields["company"];
        $navigate_data['x_address']            = $ps_fields["address_1"];
        $navigate_data['x_city']               = $ps_fields["city"];
        $navigate_data['x_state']              = $ps_fields["state"];
        $navigate_data['x_zip']                = $ps_fields["zip"];
        $navigate_data['x_country']            = $ps_fields["country"];
        $navigate_data['x_phone']              = $ps_fields["phone"];
        $navigate_data['x_fax']                = '';
        $navigate_data['x_Email']              = $ps_fields["email"];
        $navigate_data['x_cust_id']            = '';
        $navigate_data['x_customer_ip']        = $details["customer_ip"];

        if ($settings["test_mode"]) {
            $navigate_data['x_test_request'] = 'true';
        }

        $result = self::do_payment($navigate_data);
        if (is_wp_error($result)) {
            switch($result->get_error_code()) {
                // Non-200 response, so failed... (e.g. 401, 403, 500 etc).
                case 1:
                    $error_message = "Error communicating with gateway. Please check with the site owner (invalid response code).";
                break;
                // Gateway error (data etc)
                case 2:
                    $errors = join(", ", $result->get_error_data());
                    $error_message = "Gateway Error: " . $errors;
                break;
                // Declined - error data is array with keys: message, id
                case 3:
                    $data = $result->get_error_data();
                    $message = $data["message"];
                    $error_message = "Payment Declined: " . $message;
                break;
                // Exception caught, something bad happened. Data is exception
                case 4:
                    $error_message = "Unknown gateway error.";
                break;
            }

            // Payment for single transaction was not successful
            return self::set_validation_result($validation_result, $_POST, $error_message);
        } else {
            self::$transaction_response = array(
                'transaction_id' => $result['transaction_id'],
                'reference'      => $details["reference"],
                'amount'         => $navigate_data['x_amount'],
                'city'           => $navigate_data['x_city'],
                'state'          => $navigate_data['x_state'],
                'country'        => $navigate_data['x_country']
            );
            $validation_result["is_valid"] = true;
        }

        return $validation_result;
    }

    /**
     * @static Update the entry in the database with the payment details
     * @param $entry
     * @param $form
     */
    public static function merchantplus_after_submission($entry, $form)
    {
        $city     = self::$transaction_response["city"];
        $state    = self::$transaction_response["state"];
        $country  = self::$transaction_response["country"];
        $entry_id = rgar($entry, 'id');
        if (!empty(self::$transaction_response)) {
            //Current Currency
            $currency                  = GFCommon::get_currency();
            $transaction_id            = self::$transaction_response["transaction_id"];
            $amount                    = self::$transaction_response["amount"];
            $payment_date              = gmdate('Y-m-d H:i:s');
            $entry["currency"]         = $currency;
            $entry["payment_status"]   = 'Approved';
            $entry["payment_amount"]   = $amount;
            $entry["payment_date"]     = $payment_date;
            $entry["transaction_id"]   = $transaction_id;
            $entry["reference"]        = self::$transaction_response["reference"];
            $entry["transaction_type"] = "1";
            $entry["is_fulfilled"]     = true;
    
    RGFormsModel::update_lead($entry);
    ?>
        <script type='text/javascript'>
            _gaq.push(['_addTrans',
                <?php echo $entry["transaction_id"]; ?>,
                <?php bloginfo('name'); ?>,
                <?php echo $entry["payment_amount"]; ?>,
                ,
                ,
                <?php echo $city; ?>,
                <?php echo $state; ?>,
                <?php echo $country; ?>,
            ]);
            _gaq.push(['_trackTrans']);
            (function() {
                var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
                ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
            })();
        </script>
    <?php 
        }

    }

    /**
     * @static Sets the validation result if unsuccessful
     * @param $validation_result
     * @param $post
     * @param $error_message
     * @return array
     */
    private static function set_validation_result($validation_result, $post, $error_message)
    {

        $credit_card_page = 0;
        foreach ($validation_result["form"]["fields"] as &$field) {
            if ($field["type"] == 'creditcard') {
                $field["failed_validation"] = true;
                $field["validation_message"] = $error_message;
                $credit_card_page = $field["pageNumber"];
                break;
            }

        }
        $validation_result["is_valid"] = false;

        GFFormDisplay::set_current_page($validation_result["form"]["id"], $credit_card_page);

        return $validation_result;
    }

    /**
     * @static Uninstall the plugin
     *
     */
    public static function uninstall()
    {
        if (!GFMerchantplus::has_access('gravityforms_merchantplus_uninstall'))
            die(__('You don\'t have adequate permission to uninstall the Merchantplus Add-On.', 'navigate-merchantplus'));

        //Deactivating plugin
        $plugin = 'navigate-merchantplus/navigate_merchantplus.php';
        deactivate_plugins($plugin);
        update_option('recently_activated', array($plugin => time()) + (array)get_option('recently_activated'));
    }

    /**
     * @static Check for gravity forms installation
     * @return bool
     */
    private static function is_gravityforms_installed()
    {
        return class_exists('RGForms');
    }

    /**
     * @static Check for GravityForms
     * @return bool|mixed
     */
    private static function is_gravityforms_supported()
    {
        if (class_exists('GFCommon')) {
            $is_correct_version = version_compare(GFCommon::$version, self::$min_gravityforms_version, '>=');
            return $is_correct_version;
        } else {
            return false;
        }
    }

    /**
     * @static Check that the current user has access (for member capabilities)
     * @param $required_permission
     * @return bool|string
     */
    protected static function has_access($required_permission)
    {
        $has_members_plugin = function_exists('members_get_capabilities');
        $has_access = $has_members_plugin ? current_user_can($required_permission) : current_user_can('level_7');
        if ($has_access)
            return $has_members_plugin ? $required_permission : 'level_7';
        else
            return false;
    }


    /**
     * @static Determines if the current page is a 'Merchantplus' page
     * @return bool
     */
    private static function is_merchantplus_page()
    {
        $current_page = trim(strtolower(RGForms::get('page')));
        return in_array($current_page, array('gf_merchantplus'));
    }

    /**
     * @static Determines the URL of the plugins root folder
     * @return mixed
     */
    private static function get_base_url()
    {
        return plugins_url(null, GRAVITYFORMS_MERCHANTPLUS_FILE);
    }

    /**
     * @static Gets the base path of the plugin's folder
     * @return string
     */
    private static function get_base_path()
    {
        $folder = basename(dirname(__FILE__));
        return WP_PLUGIN_DIR . '/' . $folder;
    }

    public static function field_settings_js () {
    ?>
        <script type='text/javascript'>
            function gf_paymentspring_populate_select() {
                // Populates the select dropdowns in the credit card field properties
                // tab. Updates list on field addition and deletion.
                var options = ["<option value=''></option>"];
                jQuery.each(window.form.fields, function(i, field) {
                    if (field.inputs){
                        jQuery.each(field.inputs, function(i, input) {
                            options.push("<option value='", input.id, "'>", field.label, " (", input.label, ") (ID: ", input.id, ")</option>");
                        });
                    } else {
                        options.push("<option value='", field.id, "'>", field.label, " (ID: ", field.id, ")</option>");
                    }
                });
                jQuery("select[id^=field_paymentspring_]").html(options.join(""));
            }
            jQuery(document).bind("gform_field_deleted", gf_paymentspring_populate_select);
            jQuery(document).bind("gform_field_added", gf_paymentspring_populate_select);
            gf_paymentspring_populate_select();

            // Makes anything with the '.paymentspring_card_setting' class appear
            // when the credit card settings drop down is clicked.
            fieldSettings["creditcard"] += ", .paymentspring_card_setting";

            // Initializes inputs to stored values.
            jQuery(document).bind("gform_load_field_settings", function (event, field, form) {
                jQuery("#field_paymentspring_card_value").attr("checked", field["field_paymentspring_card"] == true);
                jQuery("#paymentspring_customer_fields").toggle(field["field_paymentspring_card"] == true);

                var fields = [ <?php foreach ( GFMerchantplus::paymentspring_fields() as $key => $value ) { echo "'{$key}',"; } ?> ];
                fields.map(function(fname) {
                    jQuery("#field_paymentspring_" + fname).attr("value", field["field_paymentspring_" + fname]);
                });
            });
        </script>
    <?php
    }
    public static function paymentspring_fields () {
        return array(
            "amount" => "Amount",
            "first_name" => "First Name",
            "last_name"  => "Last Name",
            "address_1"  => "Address 1",
            "address_2"  => "Address 2",
            "city"       => "City",
            "state"      => "State",
            "zip"        => "Zip",
            "country"    => "Country",
            "phone"      => "Phone",
            "fax"        => "Fax",
            "website"    => "Website",
            "company"    => "Company",
            "email"      => "Email"
        );
    }

    public static function field_settings_checkbox ( $position, $form_id ) {
        // right below Field Label
        if ( $position == 25 ) {
          ?>
          <li class="paymentspring_card_setting field_setting">
            <input type="checkbox" id="field_paymentspring_card_value" onclick="jQuery('#paymentspring_customer_fields').toggle(); SetFieldProperty('field_paymentspring_card', this.checked);" />
            <label for="field_paymentspring_card_value" class="inline"><?php _e( "Use with Navigate Merchantplus?", "gf_paymentspring" ); gform_tooltip( "gf_paymentspring_use_card_checkbox" ); ?></label>
            <div id="paymentspring_customer_fields">
                <table style="width:375px">
                    <tbody>
                        <?php
                        $form = RGFormsModel::get_form_meta_by_id( $form_id );
                        foreach ( GFMerchantplus::paymentspring_fields() as $key => $value ) {
                            echo "<tr>";
                            echo "<td style='width:100px'>";
                            echo "<label for='field_paymentspring_{$key}'>{$value}</label>";
                            echo "</td>";
                            echo "<td>";
                            echo "<select style='width:100%' id='field_paymentspring_{$key}' onchange=\"SetFieldProperty('field_paymentspring_{$key}', this.value);\">";
                            echo "</select>";
                            echo "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </li>
        <?php
        }
    }
}

?>